import numpy as np

def print_num(num):
    if num == 1:
        print("""
              -----------
              |         |
              |    *    |
              |         |
              -----------
              You got a one.
              """)
    elif num == 2:
        print("""
              -----------
              |  *      |
              |         |
              |      *  |
              -----------
              You got a two.
              """)
    elif num == 3:
        print("""
              -----------
              | *       |
              |    *    |
              |       * |
              -----------
              You got a three.
              """)
    elif num == 4:
        print("""
              -----------
              |  *   *  |
              |         |
              |  *   *  |
              -----------
              You got a four.
              """)
    elif num == 5:
        print("""
              -----------
              | *     * |
              |    *    |
              | *     * |
              -----------
              you got a five.
              """)
    else:
        print("""
              -----------
              | *     * |
              | *     * |
              | *     * |
              -----------
             You got a six.
              """)


print("****************Roll a dice game!**********************")
print("This is a two player game where the players are competing to reach 20 points first!")
print("Your goal is to roll the same number one both dice. Doing this will reward you with the number you rolled as the amount of points!")
done = False
player_one_score = 0
player_two_score = 0
count = 0
player_one = input("Player one enter your name: ")
player_two = input("Player two enter your name: ")
print("If you would like to stop type 'stop'")
while not done:
    print("If you would like to stop type 'stop'")
    count += 1
    if count % 2 == 0:
        print(str(player_two) + "'s turn")
    else:
        print(str(player_one) + "'s turn")
    number_one = np.random.randint(1,6)
    number_two = np.random.randint(1,6)
    roll = input("Type 'roll' or 'r' and hit enter to roll: ")
    if roll == "roll" or roll == "r":
        print_num(number_one)
        print_num(number_two)
        if number_one == number_two:
            if count % 2 == 0:
                player_two_score += number_one
                print(str(player_two) + " scored " + str(number_one) + "!")
                print(str(player_two) + " now has: " + str(player_two_score))
            else:
                player_one_score += number_one
                print(str(player_one) + " scored " + str(number_one) + "!")
                print(str(player_one) + " now has: " + str(player_one_score))
            if player_one_score >= 20:
                print(str(player_one) + " wins!")
                break
            elif player_two_score >= 20:
                print(str(player_two) + " wins!")
                break
    if roll == "stop" or roll == "q":
        print("Thanks for playing!")
        done = True
    else:
        print("Invalid input")